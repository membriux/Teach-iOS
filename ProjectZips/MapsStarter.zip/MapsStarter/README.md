## Starter Project for Photo Map Exercise (Swift)
![Photo Map walkthrough](/CompletedProjects/CompletedMaps/walkthrough.gif)

- Connects with Foursquare API
- Implements `LocationsViewController`
- Placeholders for `PhotoMapViewController` and `FullImageViewController`

    
