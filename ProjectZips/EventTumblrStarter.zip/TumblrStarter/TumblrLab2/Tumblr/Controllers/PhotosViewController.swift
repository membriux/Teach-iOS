//
//  PhotosViewController.swift
//  Tumblr
//
//  Created by Memo on 10/4/18.
//  Copyright © 2018 Membriux. All rights reserved.
//

import Foundation
import UIKit
import AlamofireImage

class PhotosViewController: UIViewController  {
    
    
    // Connect Tableview and Cell to tableView

    
    
    // Create Posts array
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        
        
    }
    
    // Get posts from Tumblr API
    func getPosts() {
        
    }

    
    // TableView Functionality that displays images
    
    
}

