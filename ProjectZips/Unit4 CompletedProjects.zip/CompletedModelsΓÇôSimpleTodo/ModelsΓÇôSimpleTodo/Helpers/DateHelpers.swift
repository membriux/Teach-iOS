//
//  DateHelpers.swift
//  Models–SimpleTodo
//
//  Created by Memo on 1/31/19.
//  Copyright © 2019 Membriux. All rights reserved.
//

import Foundation


struct DateFormat {
    
    
    static let eventDateAndTime = "EEEE MMM d yyyy h:mm a"
    static let noteDate = "MMM d, h:mm a"
    
    
}
