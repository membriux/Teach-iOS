//
//  PostCell.swift
//  tumblerLab
//
//  Created by Memo on 1/10/19.
//  Copyright © 2019 Membriux. All rights reserved.
//

import UIKit

class PhotosTableViewCell: UITableViewCell {

    @IBOutlet weak var photoImage: UIImageView!
    // ––––– TODO: Connect UIImageView
    
    
    
}
